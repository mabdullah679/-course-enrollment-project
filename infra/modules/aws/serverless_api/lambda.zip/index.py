import json

def _resp(code=200, body=None):
    return {
        "statusCode": code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body if body is not None else {})
    }

def handler(event, context):
    path   = event.get("rawPath", "/")
    method = event.get("requestContext", {}).get("http", {}).get("method", "GET")

    if method == "GET" and path == "/health":
        return _resp(200, {"ok": True})

    if method == "POST" and path == "/echo":
        body = event.get("body")
        try:
            data = json.loads(body) if body else {}
        except Exception:
            return _resp(400, {"error": "invalid JSON"})
        return _resp(200, {"received": data})

    if method == "POST" and path == "/enroll":
        body = event.get("body")
        data = json.loads(body) if body else {}
        return _resp(201, {"enrolled": data})

    return _resp(200, {"message": "pong", "input": event})
